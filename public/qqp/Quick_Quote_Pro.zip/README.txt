QUICK QUOTE PRO — SETUP GUIDE
Powered by Hero Vehicle Care
=================================================

WHAT THIS IS
A quote calculator that installs on your phone like a real app —
home screen icon, opens full-screen, works offline, no App Store
needed. It's yours to rebrand with your own business name, logo,
color, pricing, and services.

What you can do with it:
  - Get an instant price range for any job, in a few taps
  - Offer several options on one quote (Option 1, Option 2, ...)
  - Save quotes to an in-app "My Saved Quotes" list
  - See who's due for a callback under "Follow-Ups"
  - Text or email a quote straight from the app
  - Download a saved quote as a branded, print-ready PDF
  - Export your whole saved-quote list as a spreadsheet (CSV)
  - One-tap "Add to Calendar" and "Save Contact" for follow-ups
  - Add a photo of the vehicle to any quote
  - Add your Stripe/Square/PayPal deposit link so it's included
    automatically on every quote you send


STEP 1 — GET IT ONLINE (2 minutes, free)
-------------------------------------------
"Add to Home Screen" only works over a real https:// web address,
so this needs to be hosted somewhere first.

  1. Unzip this download. You'll get a folder with these files
     in it.

  2. Go to  netlify.com/drop

  3. Drag the whole unzipped folder onto that page.

  4. A few seconds later you'll have a live link. That's your app.

No account needed. No database. No server to manage.

Other options that work the same way: GitHub Pages, or your own
website host (ask them how to upload a static folder, or point a
subdomain like quote.yourbusiness.com at it).

A note on Vercel: it's a good host, but its drag-and-drop expects
a GitHub repo or its command-line tool, and its "build with AI"
page is a different product that will ask you for credits. For a
ready-made folder like this one, Netlify Drop is the easy path.

If your link shows "404" or "this page doesn't exist", you most
likely dragged the .zip file itself instead of the unzipped
folder, or dragged a folder with the app folder inside it. Open
it until you can see index.html sitting right there, then drag
that folder.


STEP 2 — ADD IT TO YOUR HOME SCREEN
--------------------------------------
Once you have your live link, open it on your phone:

  - iPhone (Safari): tap the Share icon → "Add to Home Screen"
  - Android (Chrome): tap the install banner if it appears, or the
    ⋮ menu → "Install app" / "Add to Home Screen"

It'll now open full-screen with its own icon, exactly like any
other app on your phone.


STEP 3 — MAKE IT YOURS
--------------------------
No code editing needed for any of this — it's all done by tapping
around inside the app itself:

BRAND (tap the ⚙ gear icon, top right):
  1. Enter your business name
  2. Pick an accent color (or build your own custom color)
  3. Upload your logo, or paste a link to one
  4. Paste your Stripe/Square/PayPal deposit link (optional)
  5. Tap Save

PRICING, SERVICES & VEHICLES ("Manage services, vehicles &
pricing" below the quote box):
  - Rename or re-price any vehicle type, condition, service, or
    add-on to match what you actually charge
  - Tap "+ Add" on any category to create a new one
  - Tap the × next to a row to remove it
  - "Reset All To Defaults" brings back the original setup any time

WHAT-TO-SAY SCRIPT (in the same panel):
  - Rewrite the script your team reads out loud, in your own words
  - Drop in tokens like {price_low} or {vehicle} and it fills in
    automatically for every quote

Everything you set up is saved on your device and stays there even
if you close the app or restart your phone.


OPTIONAL — CHANGING THE NAME UNDER YOUR HOME SCREEN ICON
-------------------------------------------------------------
Everything above changes what you see and use day to day. The one
thing it can't change is the exact text underneath your home screen
icon (that's set once, in a settings file). Most people are happy
leaving this as "Quick Quote Pro" — but if you'd rather it show
your own business name there too:

  1. Open manifest.json in any text editor
  2. Change "name" and "short_name" to your business name
  3. Re-upload the folder wherever you hosted it in Step 1

That's the only file that ever needs manual editing, and it takes
about 30 seconds.


UPDATING LATER
-----------------
If you ever receive an updated copy, just re-upload the folder,
replacing the old files. Installed phones pick the update up on
their own the next time the app is opened with a signal.


YOUR LICENSE
----------------
This copy is licensed to your business for your own use. In plain
terms: it's yours to use and customize for your own company, but
not to resell, redistribute, or share as your own product. Full
terms are in LICENSE.txt in this folder.


FILES IN THIS FOLDER
-----------------------
  index.html     → opens straight into the app
  app.html       → the app itself
  manifest.json  → app name/icon settings (see optional step above)
  sw.js          → makes offline mode work
  LICENSE.txt    → your license terms
  HOW_TO_USE.pdf → full guide to every feature, including the newest ones

Note: your logo and home screen icons are built directly into the
app now (no separate icons folder) — upload a new logo any time via
the ⚙ gear icon and everything updates together.


Questions? Reach out to whoever you purchased this from.
